# https-colab.research.google.com-drive-1Zg2p8jVlad34VZSI47RVfBd44t3xdPnj-scrollTo-ZPwB5vYCom4N-uniq
Introduction to Python
